#!/bin/bash

# 创建临时文件
sudo touch ./tmp.log
sudo chmod 777 ./tmp.log


# 函数：检查端口是否通
check_port_done() {
    
    echo "${tenant} 开始执行"
    # 使用nc命令检查端口连接情况
    nc -z -w3 $ip $port

    # 检查nc命令的退出状态
    if [ $? -eq 0 ]; then
        
        # # 将脚本传到租户服务器上
        scp -o StrictHostKeyChecking=no -P $port ./tenant_message.sh swadmin@$ip:/tmp

        # # 执行租户服务器上的脚本
        tenant_message=$(ssh  -o StrictHostKeyChecking=no   swadmin@$ip -p $port "bash /tmp/tenant_message.sh" )
       echo ${tenant} ${tenant_message} >> ./tmp.log

    else
        echo "${tenant} ${ip} ${port}不通 " >> ./tmp.log       
    fi
}

# 获取租户信息
for line in `cat /ops/list`
do
{
    # 使用 cut 命令分割字符串
    part1=$(echo "$line" | cut -d'-' -f1)
    part2=$(echo "$line" | cut -d'-' -f2)
    part3=$(echo "$line" | cut -d'-' -f3)
    part4=$(echo "$line" | cut -d'-' -f4)

     if [ -n "$part4" ]; then
            tenant=$part1-$part2 
            ip=$part3 
            port=$part4
    else
            tenant=$part1
            ip=$part2
            port=$part3
    fi

    # 执行检查端口是否通的函数,并将结果写入日志文件
    check_port_done
} &
done
wait

# # 将结果写入google sheets
/usr/local/bin/python3.9 ./auto_write_google.py

sudo rm -rf ./tmp.log