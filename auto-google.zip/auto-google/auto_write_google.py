import os
import sys
import google.auth
from googleapiclient.discovery import build
from google.oauth2.service_account import Credentials
# pip3.9 install --upgrade google-api-python-client google-auth-httplib2 google-auth-oauthlib
# 如果有`credentials.json`文件，请将其路径放入环境变量中
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "./credentials.json"

# 创建服务对象
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
creds = None
creds, _ = google.auth.default(scopes=SCOPES)

service = build('sheets', 'v4', credentials=creds)

# The ID of the spreadsheet. 可以从Google Sheets的URL中获取
SPREADSHEET_ID = '1meu8r9M7yDSWS544sPQfvB1ELCcv_ncPT7QRTUW_JZU'

# 要写入的数据
filename = './tmp.log'

# 初始化一个空数组
data = []

# 打开文件进行读取
with open(filename, 'r', encoding='utf-8') as file:
    # 遍历文件中的每一行
    for line in file:
        # 去除行末的换行符并按空格分割
        words = line.strip().split()
        # 将分割后的单词列表添加到数组中
        data.append(words)



# 创建要更新的数据范围和数据
body = {
    'values': data
}

# 将数据写入Google Sheets
range_name = 'Sheet1'  # 这里指定了要更新的范围
result = service.spreadsheets().values().update(
    spreadsheetId=SPREADSHEET_ID,
    range=range_name,
    valueInputOption='RAW',
    body=body
).execute()

print(f"{result.get('updatedCells')} cells updated.")