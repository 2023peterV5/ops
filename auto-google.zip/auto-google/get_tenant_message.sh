#!/bin/bash

conf_path=/opt/lucky/openresty/nginx/conf/public.conf
amazonaws=`grep amazonaws $conf_path |awk -F '.' 'NR==1{print $4}'`
tenant=`hostname | awk -F '-' '{print $1}'`
demo_tag=`grep amazonaws $conf_path |awk -F '.' 'NR==1{print $5}' |awk -F '/' '{print $2}'`
version=`grep amazonaws $conf_path |awk -F '.' 'NR==1{print $5}' |awk -F '/' '{print $3}'`

if [ -n "$amazonaws" ]; then
   #echo " $tenant $demo_tag $version "   
   echo "  $demo_tag $version "   
else
    echo "  '无s3' '无' "
fi